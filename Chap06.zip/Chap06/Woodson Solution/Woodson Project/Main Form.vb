' Project name:         Woodson Project
' Project purpose:      Totals the sales amounts entered by the user
'                       and then calculates a 10% bonus
' Created/revised by:   <your name> on <current date>

Option Explicit On
Option Strict On
Option Infer Off

Public Class MainForm

    Private Sub exitButton_Click(sender As Object, e As EventArgs) Handles exitButton.Click
        Me.Close()
    End Sub

End Class
